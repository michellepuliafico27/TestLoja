package americanas.pages;

public class LandingPage {
}
